# Attendance
Code used for PHP Bootstrap 4 Form and CRUD Application Development Exercises.

See Full Playlist or Lessons on <br/>
[Udemy](http://bit.ly/2Y037Mb) <br/>
[Skillshare - 2 Months Free Premium Membership](https://skl.sh/2p3vTxQ)

PHP Bootstrap 4 CRUD Application for educational purposes. This project implements:

PHP
MySQL
PHP PDO
Bootstrap 4
Authentication and Authorization
GitHub
Heroku
Is built in part for Udemy/SkillShare/Uthena course entitled: "Complete Core 3.1 and Entity Framework Development"
