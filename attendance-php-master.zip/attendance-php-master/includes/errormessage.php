<div class="alert alert-danger" role="alert">
    Operation Encountered An Error. Please retry. 
</div>